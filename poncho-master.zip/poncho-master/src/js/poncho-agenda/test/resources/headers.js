const jsonData = {
    "desde": "Desde",
    "hasta": "Hasta",
    "horario": "Horario",
    "filtro-ministerio": "Ministerio",
    "descripcion": "Evento"
};

module.exports = jsonData;
