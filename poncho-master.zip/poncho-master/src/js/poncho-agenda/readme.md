# 📦 Agenda

Agrupa entradas JSON por fecha de inicio, fecha de fin y una categoría definida
por el usuario.

## 🧰 Opciones y métodos

### Opciones iniciales

| Parámetro | Tipo | Default | Descripción |
|:---|:---|:---|:---|
|  |  |  |  | 




# 🚀 Uso
