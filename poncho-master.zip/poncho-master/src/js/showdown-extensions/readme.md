# Extensiones Markdown para ShowdownJs

## Evaluador de extensiones

<iframe height="500" style="width: 100%;" scrolling="no" title="Parser markdown" src="https://codepen.io/agustinbouillet/embed/YzGYbwO?default-tab=result&theme-id=light" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/agustinbouillet/pen/YzGYbwO">
  Parser markdown</a> by Agustín Bouillet (<a href="https://codepen.io/agustinbouillet">@agustinbouillet</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>