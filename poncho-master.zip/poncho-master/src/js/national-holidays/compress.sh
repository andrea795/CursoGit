sass --update --trace ./src/scss/_national-holidays.scss:./dist/css/national-holidays.css --style compressed;
