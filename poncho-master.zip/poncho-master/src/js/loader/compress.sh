sass --watch --trace ./src/scss/loader.scss:./dist/css/loader.css --style compressed;
